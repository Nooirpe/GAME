#ifndef _DEFS_H
#define _DEFS__H

#define SCREEN_WIDTH 1366
#define SCREEN_HEIGHT 768

#define PLAYER_SIZE 64

#define WINDOW_TITLE "RunMo!"

#endif